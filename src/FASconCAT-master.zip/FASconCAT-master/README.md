# FASconCAT
FASconCAT is written on Linux and works on WindowsPCs, Macs and Linux running
systems. If input files are coming from Windows CRLF line feeds should be converted
into Unix (LF) line feeds. This can be done in several editors like e.g. Bioedit or
Notepad++. FASconCAT usually replaces them, but might not succeed in every instance.
Please read manual instructions for further information.
